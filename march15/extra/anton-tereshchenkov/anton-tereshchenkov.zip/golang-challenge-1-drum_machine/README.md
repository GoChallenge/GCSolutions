Git repository included in this archive.

A basic implementation of encoding can be found on branch `encode`.

Example for adding more steps to cowbell track can be found in
`pattern_example_test.go`:
  - Without encoding - add steps to the pattern and print it
  - With encoding - add steps to the pattern, write to file, decode the
    resulting file and then print the pattern
