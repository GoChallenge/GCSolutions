package drum

// Sample represents the raw data for a single
type Sample struct {
	Buffer   []float32
	Playhead int
}
