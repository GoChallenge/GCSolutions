// Package drum implements the decoding and encoding of .splice drum machine files.
// See golang-challenge.com/go-challenge1/ for more information
package drum
