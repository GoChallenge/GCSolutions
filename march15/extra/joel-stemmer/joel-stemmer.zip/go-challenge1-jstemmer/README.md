# Go challenge 1 submission

Decoder and encoder for .splice files.

The code in `cmd/add-cowbell/` assumes the base dir (where this README is
located) is in `$GOPATH/src/github.com/jstemmer/go-challenge1`.
