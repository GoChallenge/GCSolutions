This is Gautam Dey's entry to the Go Challenge #1.
Gautam Dey<gautam.dey77@gmail.com>
