Drum
====

Here is my entry for the go programming challenge.  Thanks, that was fun.

Craig Swank
craigswank@gmail.com
