Implementation of the Go Challenge 1

* Author: Alexandre Grison
* Country: France
* Twitter: @algrison

Thanks for the challenge :-)
