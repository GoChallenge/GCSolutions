#!/bin/bash

go test -test.benchmem -bench .