#!/bin/bash

go test -gcflags="-m" .