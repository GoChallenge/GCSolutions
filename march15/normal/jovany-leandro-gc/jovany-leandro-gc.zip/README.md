go-challenge-1
==============

#Pattern

FILE: 12B(file id)1B(file size/byte)32B(version/string)4B(tempo float 32bit)<Track>
Track: 4B(id/uint32)1B(size key/byte)..(+size key)16B(step)