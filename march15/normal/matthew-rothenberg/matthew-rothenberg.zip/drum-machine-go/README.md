Golang Challenge #1
-------------------
This version submitted by Matthew Rothenberg.

https://github.com/mroth

